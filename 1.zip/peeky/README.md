
## Peeky Setup

1. Run following command
   ```pip install -r requirements.txt```
2. Remove word example from file example.env it becomes .env that what we want
3. Add all things asked in .env file
```
API_ID =[Get it from https://my.telegram.org/auth?to=apps]
API_HASH=[Get it from https://my.telegram.org/auth?to=apps]
BOT_TOKEN=[Get it from Bot Father]
CHAT_ID=[Group id or Channel id Where you want cc to get dropped]
```

4. Run following command
```python3 main.py```


#### Coded with ❤️ by @notxok
